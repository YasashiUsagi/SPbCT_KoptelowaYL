package com.metanit;

public class Main {

    public static void main(String[] args) {
        System.out.println("Hello Java!");

        double a = 3;
        double b = 4;
        double c;
        c = Math.sqrt (a* a + b* b);
        System.out.println ("c = "+ c);
    }
}
